
# coding: utf-8

# In[ ]:


import sys
import thegameoflife_fortests
s = "test"
CountGoodTests = 0;
for i in range(20):
    s0 = s + str(i)
    sys.stdin = open(s0,"r")
    t = 1
    sys.stdout = open("output.txt","w")
    q = 1                
    thegameoflife_fortests.modeling(t, q)
    sys.stdin.close()
    sys.stdout.close()
    sys.stdin = open(s0+"check","r")
    checker = open("output.txt", "r")
    generations = int(sys.stdin.readline())
    ls = sys.stdin.readline().split()
    for line in checker:
        strr = sys.stdin.readline()
        flag = 0
        for ff in range(int(ls[1])):
            if strr[ff] != line[ff]:
                flag = 1
                break
        if flag == 1:
            CountGoodTests -= 1
            break
    CountGoodTests += 1
    Checker.close()
    sys.stdin.close()
sys.stdout = open("RESULT.txt","w")    
sys.stdout.write(CountGoodTests)
sys.stdout.close()


